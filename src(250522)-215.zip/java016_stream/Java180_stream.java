package java016_stream;

/*
 * 리소드 자동 닫기
 * 
 */
public class Java180_stream {

	public static void main(String[] args) {		

	}
}
