package java012_api.part03;

public class Person {
	String name;
	
	public Person() {
	
	}

	public Person(String name) {
		this.name = name;
	}
	
	
}
