package java008_static_access.part02;

public class Java085_static {

	public static void main(String[] args) {
		//System.out.println(OrderStatic.y);
		System.out.println(OrderStatic.z);
		//OrderStatic.process();
		//OrderStatic os = new OrderStatic();
		

	}

}
