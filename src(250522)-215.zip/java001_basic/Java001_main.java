package java001_basic;

public class Java001_main {
	
	public static void main(String[] args) {   // 프로그램 시작
		System.out.println("Hello java!");  // sysout 적고 Ctrl+Space
	} // 프로그램 끝
	
}
//	Ctrl+Space
