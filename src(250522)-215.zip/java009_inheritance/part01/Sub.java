package java009_inheritance.part01;

public class Sub extends Father{
	public Sub() {
	
	}
}
