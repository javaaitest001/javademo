package java009_inheritance.part06;

public class PetOver {
	
	public PetOver() {
	
	}
	
	public void move() {
		System.out.println("수퍼클래스 move() : 애완동물이 움직입니다.");
	}
} // end class
