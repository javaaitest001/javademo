package java009_inheritance.part06;

public class Java098_inheritance {

	public static void main(String[] args) {
		PetOver pet = new PetOver();
		pet.move();
		
		DogOver dog = new DogOver();
		dog.move();
		
		BirdOver bird = new BirdOver();
		bird.move();

	} // end main()

} // end class
