package java009_inheritance.part04;

public class Parent {
	String name;
	int age;
	
	public Parent() {
	
	}

	public Parent(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	
	
} // end class
