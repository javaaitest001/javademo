package java009_inheritance.part04;

public class Java096_inheritance {

	public static void main(String[] args) {
		Son son = new Son("홍길동", 30, "기획부");
		System.out.println(son.toString());

	} // end main()

} // end class
