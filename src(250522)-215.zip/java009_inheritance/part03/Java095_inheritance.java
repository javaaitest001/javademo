package java009_inheritance.part03;

public class Java095_inheritance {

	public static void main(String[] args) {
		SubConst sc = new SubConst(10, 20);
		System.out.printf("x=%d y=%d", sc.x, sc.y);

	} // end main()

} // end class
