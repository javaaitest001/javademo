package java009_inheritance.part03;

public class SuperConst {
	int x;
	int y;
	
	public SuperConst(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	} // end SuperConst()
	
} // end class
