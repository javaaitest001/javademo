package java009_inheritance.part03;

public class SubConst extends SuperConst{

	public SubConst(int x, int y) {
		super(x, y);
	}
	
} // end class
