package java009_inheritance.part02;

public class MyChild extends MyFather{
	
	public MyChild() {
		super();
		System.out.println("MyChild");
	}

} // end class
