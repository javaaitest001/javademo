package java009_inheritance.part02;

public class MyFather extends MyGrand{
	
	public MyFather() {
		super();
		System.out.println("MyFather");
	}

} // end class
