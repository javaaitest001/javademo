package java009_inheritance.part02;

public class Java094_inheritance {

	public static void main(String[] args) {
		
		MyChild child = new MyChild();
		

	} // end main()

} // end class
