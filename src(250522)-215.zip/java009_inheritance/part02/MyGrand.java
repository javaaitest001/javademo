package java009_inheritance.part02;

public class MyGrand /* extends Object */{

	public MyGrand() {
		super(); // 수퍼클래스의 생성자 호출
		System.out.println("MyGrand");
	}

} // end class
