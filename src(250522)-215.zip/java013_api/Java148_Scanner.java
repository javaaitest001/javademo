package java013_api;

import java.util.Scanner;

public class Java148_Scanner {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		while(true) {
		
			System.out.printf("단입력: ");
			int selectNum = sc.nextInt();
			for(int i = 1; i <= 9; i++) {
				System.out.printf("%d X %d = %d\n", selectNum, i, selectNum * i);
			}
			
			System.out.println("계속하시겠습니까?(종료:n, 계속:아무키)");
			String chk = sc.next();
			if(chk.equals("n") || chk.equals("N")) {
				System.out.println("프로그램종료");
				return;
			}
			
		}
		
	}

}
