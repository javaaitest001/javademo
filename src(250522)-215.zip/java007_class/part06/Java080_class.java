package java007_class.part06;

public class Java080_class {

	public static void main(String[] args) {
		Calculator cal = new Calculator();
		cal.addValue(4, 8);
		cal.addValue(2, 5, 7);
		cal.addValue(2.3f, 3.4f);
		cal.addValue(23L, 43L);

	} // end main()

} // end class