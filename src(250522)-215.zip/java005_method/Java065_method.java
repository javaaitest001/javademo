package java005_method;

public class Java065_method {

	public static void main(String[] args) {
		char[] data = {'a', 'b', 'c', 'd'};
		
		System.out.println(data); // abcd
		
		int[] num = {1,2,3};
		System.out.println(num); // [I@36baf30c
		

	} // end main()

} // end class
