package football;

public class FootballApp {

	public static void main(String[] args) {

		new FootballManager().run();

	} // end main()

} // end class
