package java010_abstract_interface.answ.part03;

public class Whale {
	public void bear() {
		System.out.println("고래는 새끼를 낳습니다.");
	}
}
