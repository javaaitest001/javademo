package java010_abstract_interface.part01;

public class SendaAbs extends CarAbs{
	
	public SendaAbs() {
	
	}
	
	@Override
	public void work() {
		System.out.println("Senda");
		
	}
}
