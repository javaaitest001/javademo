package java010_abstract_interface.part06;

public interface Score {
	int sol = 20; // public static final
	
	int getScore(); // public abstract
}
