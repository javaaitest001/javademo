package java010_abstract_interface.part06;

public interface Print {

	public String toPaint();
}
