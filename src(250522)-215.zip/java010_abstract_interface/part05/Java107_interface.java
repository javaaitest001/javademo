package java010_abstract_interface.part05;

public class Java107_interface {

	public static void main(String[] args) {
		Life life = new Life();
		life.display();

	} // end main()

} // end class
