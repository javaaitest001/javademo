package java010_abstract_interface.part05;

public class Animal {
	
	public Animal() {
	
	}
	
	public void display() {
		System.out.println("animal");
	}
} // end class
