package java010_abstract_interface.part07;

final public class Base {
	
	public Base() {
	
	}
}
