package java010_abstract_interface.prob.part03;

public class Whale extends Fish implements Mammal{
	public Whale() {
	
	}
	
	@Override
	public void bear() {
		System.out.println("고래는 새끼를 낳습니다.");
		
	}
	
	@Override
	void swim() {
		// TODO Auto-generated method stub
		super.swim();
	}
}
