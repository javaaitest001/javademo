package java006_class.part03;

public class Java068_class {

	public static void main(String[] args) {
		
		Rect a = new Rect();
		
		a.width = 5;
		a.height = 3;
		a.color = "빨강";
		
		a.display();
		

		Rect b = new Rect();
		
		b.width = 7;
		b.height = 4;
		b.color = "파랑";
		
		b.display();
		
	} // end main()

} // end class
