package java006_class.part01;

// 사용자가 정의한 자료형
// 클래스 정의
public class Person {

	//멤버변수
	String name;
	int age;
	char gender;
	
	//생성자
	Person() {
	}

	//메소드
	void develop() {
		System.out.println("개발한다");
	}

	//메소드
	void run() {
		System.out.println("달린다");
	}
} // end Person
